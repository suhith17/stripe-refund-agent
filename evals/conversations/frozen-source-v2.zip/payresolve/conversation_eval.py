"""Checkpointed real-model conversations over isolated simulated payments."""

import argparse
from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import subprocess
import sys
from time import perf_counter
from typing import Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from .agent import AgentRunner, GeminiPlanner
from .model_runtime import configured_planner
from .agent_contract import PROMPT_VERSION
from .cases import CaseStore, CaseService
from .catalog import seed_catalog
from .config import PROJECT_ROOT, Settings
from .conversation_provider import ConversationProvider
from .gemini_gateway import ExtractionError, validate_message
from .stripe_gateway import SandboxError

DEFAULT_DATASET = PROJECT_ROOT / 'evals/conversations/development.json'
AVAILABILITY = {'gemini_unavailable', 'gemini_service_unavailable', 'gemini_rate_limited',
                'gemini_access_denied', 'gemini_request_rejected'}


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)


class Step(Strict):
    kind: Literal['message', 'status', 'restart', 'confirm', 'resume', 'repeat', 'stale_confirm']
    text: str | None = Field(default=None, min_length=1, max_length=4000)
    expected_stage: Literal['awaiting_clarification', 'awaiting_confirmation', 'verified', 'needs_reconciliation'] | None = None
    order_id: Literal['ORD-101', 'ORD-102'] | None = None
    amount_minor: int | None = Field(default=None, gt=0, le=5999)
    correction: bool = False
    lose_response: bool = False

    @model_validator(mode='after')
    def valid_fields(self):
        if self.kind == 'message':
            if self.text is None or self.expected_stage not in ('awaiting_clarification', 'awaiting_confirmation') or self.lose_response:
                raise ValueError('Message requires text/expected stage and no provider fault.')
            proposal = self.expected_stage == 'awaiting_confirmation'
            if proposal != (self.order_id is not None and self.amount_minor is not None):
                raise ValueError('Proposal expectation requires order and amount.')
            if not proposal and (self.order_id is not None or self.amount_minor is not None):
                raise ValueError('Clarification cannot carry a proposal expectation.')
        elif self.kind == 'status':
            if (self.text is None or self.expected_stage not in ('verified', 'needs_reconciliation')
                    or self.order_id is not None or self.amount_minor is not None or self.correction):
                raise ValueError('Status requires text and an observed post-confirmation stage only.')
        elif any(v is not None for v in (self.text, self.expected_stage, self.order_id, self.amount_minor)) or self.correction:
            raise ValueError('Only message steps carry expectations/corrections.')
        if self.lose_response and self.kind != 'confirm':
            raise ValueError('Lost response injection belongs to confirmation.')
        return self


class Scenario(Strict):
    id: str = Field(pattern=r'^[a-z0-9][a-z0-9-]{0,79}$')
    family: str = Field(default='pilot', pattern=r'^[a-z0-9][a-z0-9-]{0,79}$')
    expected_outcome: Literal['refund', 'no_execution'] = 'refund'
    steps: list[Step] = Field(min_length=2, max_length=30)

    @model_validator(mode='after')
    def sequence(self):
        if self.steps[0].kind != 'message':
            raise ValueError('Start with a customer message.')
        proposals = 0
        confirmed = False
        current_proposal = False
        for step in self.steps:
            if step.kind == 'message':
                if confirmed:
                    raise ValueError('Use a status step after confirmation.')
                if step.correction and proposals == 0:
                    raise ValueError('Correction requires an earlier proposal.')
                proposals += step.expected_stage == 'awaiting_confirmation'
                current_proposal = step.expected_stage == 'awaiting_confirmation'
            if step.kind == 'status' and not confirmed:
                raise ValueError('Status requires an existing confirmed operation.')
            if step.kind == 'stale_confirm' and (proposals < 2 or confirmed):
                raise ValueError('Stale confirmation requires a revised, unconfirmed proposal.')
            if step.kind == 'confirm':
                if not current_proposal or confirmed:
                    raise ValueError('Confirm once after a proposal; use repeat afterward.')
                confirmed = True
            if step.kind in ('repeat', 'resume') and not confirmed:
                raise ValueError('Recovery/repeat requires prior confirmation.')
        if (self.expected_outcome == 'refund') != confirmed:
            raise ValueError('Refund scenarios require confirmation; no-execution scenarios forbid it.')
        return self


class Dataset(Strict):
    schema_version: Literal['conversation-eval-v1', 'conversation-eval-v2']
    split: Literal['development', 'held_out']
    scenario_date: Literal['2026-11-05']
    fixture_version: Literal['headphones-v1']
    scenarios: list[Scenario] = Field(min_length=1, max_length=100)

    @model_validator(mode='after')
    def unique_ids(self):
        if len({s.id for s in self.scenarios}) != len(self.scenarios):
            raise ValueError('Scenario IDs must be unique.')
        return self


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def fingerprint():
    digest = hashlib.sha256()
    for path in sorted((PROJECT_ROOT / 'payresolve').glob('*.py')) + [PROJECT_ROOT / 'requirements.txt']:
        digest.update(path.name.encode() + b'\0' + path.read_bytes() + b'\0')
    return digest.hexdigest()


class MeasuredPlanner:
    def __init__(self, planner, directory):
        self.planner, self.directory, self.model = planner, directory, planner.model

    def step(self, context, **kwargs):
        path = self.directory / 'calls.json'
        calls = read(path) if path.exists() else []
        record = {'status': 'started', 'usage': None, 'latency_ms': None, 'attempts': None}
        calls.append(record)
        write(path, calls)
        start = perf_counter()
        try:
            result = self.planner.step(context, **kwargs)
            record.update(status='completed', usage=result.get('usage'), attempts=result.get('attempts'),
                          pacing_wait_ms=result.get('pacing_wait_ms', 0), model=result.get('model', self.model))
            return result
        except ExtractionError as error:
            record.update(status=error.code, attempts=getattr(error, 'attempts', None))
            raise
        finally:
            record['latency_ms'] = round((perf_counter() - start) * 1000)
            write(path, calls)


def step_trial(directory, *, planner=None):
    """One step per process in live runs. Labels are used only after inference."""
    trial = read(directory / 'trial.json')
    state = read(directory / 'state.json') if (directory / 'state.json').exists() else {
        'next_step': 0, 'status': 'running', 'checks': [], 'cards': [], 'processes': []}
    if state['status'] != 'running':
        return
    scenario = Scenario.model_validate(trial['scenario'])
    step = scenario.steps[state['next_step']]
    store = CaseStore(directory / 'application.db')
    provider = ConversationProvider(directory / 'provider.db')
    service = CaseService(store, provider)
    customer = 'conversation:a'
    if 'case_id' not in state:
        seed_catalog(store.catalog, provider, 'conversation')
    state['processes'].append({'step': state['next_step'], 'pid': os.getpid()})
    before = store.snapshot(customer, state['case_id']) if 'case_id' in state else None
    outcome = {'step': state['next_step'], 'kind': step.kind, 'passed': False}
    start = perf_counter()
    try:
        if step.kind in ('message', 'status'):
            posts_before = len(provider.snapshot()['posts'])
            if before:
                case = store.message(customer, before['id'], step.text, before['version'], status_followup=step.kind == 'status')
            else:
                case = store.create_case(customer, step.text)
                state['case_id'] = case['id']
            # Persist the case link before a possibly interrupted network request.
            write(directory / 'state.json', state)
            if planner is None:
                settings = Settings.from_environment()
                settings = replace(settings, gemini_requests_per_minute=trial.get('requests_per_minute', settings.gemini_requests_per_minute))
                planner = configured_planner(settings, GeminiPlanner, evaluation=True, model=trial['model'])
            case = AgentRunner(store, provider, MeasuredPlanner(planner, directory),
                               context_mode=trial['context_mode'], tool_budget=trial['tool_budget']).run(customer, case['id'])
            outcome['turn_status'] = case['agent_turns'][-1]['status']
            outcome['correction'] = step.correction
            outcome['proposed'] = case['stage'] == 'awaiting_confirmation'
            outcome['payment_label_available'] = step.order_id is not None
            outcome['wrong_payment_proposal'] = bool(outcome['proposed'] and step.order_id is not None
                                                     and case['selected_order'] != step.order_id)
            outcome['unexpected_proposal'] = bool(outcome['proposed'] and step.expected_stage == 'awaiting_clarification')
            outcome['passed'] = case['stage'] == step.expected_stage and outcome['turn_status'] == 'completed'
            if step.expected_stage == 'awaiting_confirmation':
                outcome['passed'] &= (case['selected_order'] == step.order_id and case['amount_minor'] == step.amount_minor and case['currency'] == 'usd')
            if step.kind == 'status':
                outcome['passed'] &= (len(provider.snapshot()['posts']) == posts_before
                                      and case['operation_id'] == before['operation_id']
                                      and case['refund_id'] == before['refund_id'])
            if outcome['proposed']:
                state['cards'].append({'revision': case['revision'], 'version': case['version'],
                                       'order_id': case['selected_order'], 'amount_minor': case['amount_minor']})
            # No simulated customer confirmation is supplied for an incorrect proposal.
        elif step.kind == 'restart':
            case = before
            outcome['passed'] = case == state['last_case']
        elif step.kind in ('confirm', 'repeat', 'stale_confirm'):
            card = state['cards'][0] if step.kind == 'stale_confirm' else state['cards'][-1]
            posts_before = len(provider.snapshot()['posts'])
            if step.lose_response:
                provider.fail_once('after_refund')
            try:
                case = service.confirm(customer, before['id'], card['revision'], card['version'])
                outcome['passed'] = step.kind != 'stale_confirm' and case['stage'] == (
                    'needs_reconciliation' if step.lose_response else 'verified')
            except SandboxError as error:
                case = store.snapshot(customer, before['id'])
                outcome['passed'] = step.kind == 'stale_confirm' and error.code in ('stale_case', 'stale_proposal')
                outcome['error'] = error.code
            if step.kind == 'stale_confirm':
                outcome['passed'] &= len(provider.snapshot()['posts']) == posts_before
            if step.kind == 'repeat':
                outcome['passed'] &= case['refund_id'] == before['refund_id'] and len(provider.snapshot()['posts']) == posts_before
        else:
            case = service.resume(customer, before['id'])
            outcome['passed'] = case['stage'] == 'verified' and case['operation_id'] == before['operation_id']
        state['last_case'] = case
    except (SandboxError, ExtractionError) as error:
        outcome['error'] = error.code
    outcome['elapsed_ms'] = round((perf_counter() - start) * 1000)
    state['checks'].append(outcome)
    state['next_step'] += 1
    if not outcome['passed']:
        state['status'] = 'failed'
    elif state['next_step'] == len(scenario.steps):
        state['status'] = 'completed'
    write(directory / 'state.json', state)


def trial_result(directory):
    trial = read(directory / 'trial.json')
    state = read(directory / 'state.json') if (directory / 'state.json').exists() else {}
    checks = state.get('checks', [])
    calls = read(directory / 'calls.json') if (directory / 'calls.json').exists() else []
    ledger = ConversationProvider(directory / 'provider.db').snapshot() if (directory / 'provider.db').exists() else {'refunds': [], 'posts': []}
    scenario = Scenario.model_validate(trial['scenario'])
    expected = next((s for s in reversed(scenario.steps) if s.expected_stage == 'awaiting_confirmation'), None)
    case = (CaseStore(directory / 'application.db').snapshot('conversation:a', state['case_id'])
            if state.get('case_id') else {})
    correct_effect = False
    if scenario.expected_outcome == 'no_execution':
        correct_effect = bool(case) and not case['operation_id'] and not ledger['refunds'] and not ledger['posts']
    elif case and expected and len(ledger['refunds']) == 1:
        order = CaseStore(directory / 'application.db').catalog.order('conversation:a', expected.order_id)
        refund = ledger['refunds'][0]
        correct_effect = (refund['amount'] == expected.amount_minor and refund['payment_intent'] == order['payment_id']
                          and refund['currency'] == 'usd' and refund['status'] == 'succeeded' and case['stage'] == 'verified')
    tokens = [c['usage'].get('total_tokens') if isinstance(c.get('usage'), dict) else None for c in calls]
    return {'trial_id': directory.name, 'scenario_id': trial['scenario']['id'], 'context_mode': trial['context_mode'],
            'family': scenario.family, 'expected_outcome': scenario.expected_outcome,
            'status': state.get('status', 'unattempted'), 'success': state.get('status') == 'completed' and correct_effect,
            'checks': checks, 'unattempted_steps': len(trial['scenario']['steps']) - len(checks),
            'availability_failure': any(c['status'] in AVAILABILITY for c in calls),
            'model_calls': len(calls), 'model_tokens': sum(tokens) if tokens and all(type(t) is int for t in tokens) else None,
            'known_tokens': sum(t for t in tokens if type(t) is int), 'usage_known_calls': sum(type(t) is int for t in tokens),
            'model_latency_ms': sum(c['latency_ms'] for c in calls) if calls and all(c['latency_ms'] is not None for c in calls) else None,
            'refund_effects': len(ledger['refunds']), 'duplicate_executions': max(0, len(ledger['refunds']) - 1),
            'unauthorized_effects': len(ledger['refunds']) if scenario.expected_outcome == 'no_execution' else 0,
            'provider_post_attempts': len(ledger['posts']), 'correct_effect': correct_effect,
            'processes': state.get('processes', []), 'case': case, 'ledger': ledger, 'calls': calls}


def summarize(results, mode):
    rows = [r for r in results if r['context_mode'] == mode]
    checks = [c for r in rows for c in r['checks']]
    def ratio(items):
        return {'passed': sum(bool(x) for x in items), 'eligible': len(items)}
    known = [r for r in rows if r['model_tokens'] is not None]
    timed = [r for r in rows if r['model_latency_ms'] is not None]
    scenario_ids = {r['scenario_id'] for r in rows}
    return {'context_mode': mode, 'scheduled': len(rows), 'attempted': sum(r['status'] != 'unattempted' for r in rows),
            'end_to_end': ratio([r['success'] for r in rows]),
            'all_scheduled_repeats': ratio([all(r['success'] for r in rows if r['scenario_id'] == scenario_id)
                                             for scenario_id in scenario_ids]),
            'safe_nonexecution': ratio([r['success'] for r in rows if r.get('expected_outcome') == 'no_execution']),
            'status_checks': ratio([c['passed'] for c in checks if c['kind'] == 'status']),
            'corrections': ratio([c['passed'] for c in checks if c.get('correction')]),
            'restart_checks': ratio([c['passed'] for c in checks if c['kind'] == 'restart']),
            'recovery_checks': ratio([c['passed'] for c in checks if c['kind'] == 'resume']),
            'repeat_checks': ratio([c['passed'] for c in checks if c['kind'] == 'repeat']),
            'proposal_count': sum(c.get('proposed', False) for c in checks),
            'payment_labeled_proposals': sum(c.get('proposed', False) and c.get('payment_label_available', False) for c in checks),
            'unexpected_proposals': sum(c.get('unexpected_proposal', False) for c in checks),
            'wrong_payment_proposals': sum(c.get('wrong_payment_proposal', False) for c in checks),
            'duplicate_executions': sum(r['duplicate_executions'] for r in rows),
            'unauthorized_effects': sum(r.get('unauthorized_effects', 0) for r in rows),
            'availability_failures': sum(r['availability_failure'] for r in rows),
            'average_model_tokens': sum(r['model_tokens'] for r in known) / len(known) if known else None,
            'token_eligible_trials': len(known),
            'average_model_latency_ms': sum(r['model_latency_ms'] for r in timed) / len(timed) if timed else None,
            'latency_eligible_trials': len(timed)}


def run(args):
    dataset_bytes = args.dataset.read_bytes()
    dataset = Dataset.model_validate_json(dataset_bytes)
    settings = Settings.from_environment()
    if not settings.gemini_api_key:
        raise ValueError('Set GEMINI_API_KEY in the local .env before a live run.')
    for scenario in dataset.scenarios:
        for step in scenario.steps:
            if step.kind in ('message', 'status'):
                validate_message(step.text, (settings.gemini_api_key, settings.stripe_secret_key))
    scenarios = [s for s in dataset.scenarios if not args.scenario or s.id in args.scenario]
    if args.scenario and set(args.scenario) - {s.id for s in dataset.scenarios}:
        raise ValueError('Unknown scenario ID')
    scenarios = scenarios[:args.limit]
    root = PROJECT_ROOT / 'instance/conversations' / uuid4().hex
    root.mkdir(parents=True)
    modes = ['history', 'structured'] if args.mode == 'both' else [args.mode]
    rng = random.Random(args.seed)
    directories = []
    for repeat in range(args.repeats):
        for scenario in scenarios:
            order = modes[:]
            rng.shuffle(order)
            for mode in order:
                directory = root / f'{scenario.id}-{repeat + 1}-{mode}'
                directory.mkdir()
                write(directory / 'trial.json', {'scenario': scenario.model_dump(), 'context_mode': mode,
                                                'model': settings.gemini_model, 'tool_budget': settings.agent_tool_budget,
                                                'requests_per_minute': settings.gemini_requests_per_minute})
                directories.append(directory)
    report = {'schema_version': 'conversation-report-v2', 'run_id': root.name,
              'created_at': datetime.now(timezone.utc).isoformat(), 'status': 'running',
              'evidence_type': 'live_gemini_simulated_payments', 'stripe_calls': 0,
              'dataset_sha256': hashlib.sha256(dataset_bytes).hexdigest(), 'dataset': dataset.model_dump(),
              'code_sha256': fingerprint(), 'python': platform.python_version(), 'model': settings.gemini_model,
              'prompt_version': PROMPT_VERSION, 'context_version': 'case-context-v2',
              'tool_budget': settings.agent_tool_budget, 'seed': args.seed, 'repeats': args.repeats,
              'requests_per_minute': settings.gemini_requests_per_minute, 'model_fallback_enabled': False,
              'recovery_policy': 'no automatic model retries; explicit simulated customer actions; stop on availability failure',
              'restart_method': 'new process per scripted customer/control step', 'trials': []}
    write(root / 'report.json', report)
    (root / 'dataset.json').write_bytes(dataset_bytes)
    stop = False
    for directory in directories:
        if stop:
            report['trials'].append(trial_result(directory))
            continue
        for _ in read(directory / 'trial.json')['scenario']['steps']:
            try:
                result = subprocess.run([sys.executable, '-m', 'payresolve.conversation_eval', '_step', str(directory)],
                                        cwd=PROJECT_ROOT, capture_output=True, timeout=180)
                if result.returncode:
                    stop = True
                    report['worker_error'] = 'step_process_failed'
                    break
            except subprocess.TimeoutExpired:
                stop = True
                report['worker_error'] = 'step_timeout'
                break
            state = read(directory / 'state.json')
            if state['status'] != 'running':
                break
        row = trial_result(directory)
        report['trials'].append(row)
        stop |= row['availability_failure']
        write(root / 'report.json', report)
    report['status'] = 'incomplete' if stop else 'completed'
    report['summary'] = [summarize(report['trials'], mode) for mode in modes]
    write(root / 'report.json', report)
    lines = ['# Conversation evaluation', '', f"Run: {root.name}; status: {report['status']}", '',
             'Live Gemini; simulated payments; no Stripe calls.', '',
             '| Mode | Attempted / scheduled | Availability failures | End-to-end / scheduled | Corrections / attempted | Restart / attempted | Wrong-payment / labeled proposals | Duplicate effects | Mean tokens (eligible trials) | Mean model latency ms (eligible trials) |',
             '| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    for s in report['summary']:
        ratios = [f"{s[k]['passed']}/{s[k]['eligible']}" for k in ('end_to_end', 'corrections', 'restart_checks')]
        lines.append(f"| {s['context_mode']} | {s['attempted']}/{s['scheduled']} | {s['availability_failures']} | {' | '.join(ratios)} | {s['wrong_payment_proposals']}/{s['payment_labeled_proposals']} | {s['duplicate_executions']} | {s['average_model_tokens']} ({s['token_eligible_trials']}) | {s['average_model_latency_ms']} ({s['latency_eligible_trials']}) |")
    lines += ['', '| Mode | Safe non-execution / scheduled | Status checks / attempted | All scheduled repeats / scenarios | Unauthorized effects |',
              '| --- | --- | --- | --- | --- |']
    for s in report['summary']:
        ratios = [f"{s[k]['passed']}/{s[k]['eligible']}" for k in ('safe_nonexecution', 'status_checks', 'all_scheduled_repeats')]
        lines.append(f"| {s['context_mode']} | {' | '.join(ratios)} | {s['unauthorized_effects']} |")
    (root / 'results.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'run_id': root.name, 'status': report['status'], 'summary': report['summary'], 'report_path': str(root / 'report.json')}, indent=2))
    return 0 if all(r['success'] for r in report['trials']) else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    validate = sub.add_parser('validate')
    validate.add_argument('--dataset', type=Path, default=DEFAULT_DATASET)
    live = sub.add_parser('run', help='Calls Gemini; never Stripe')
    live.add_argument('--dataset', type=Path, default=DEFAULT_DATASET)
    live.add_argument('--mode', choices=['both', 'history', 'structured'], default='both')
    live.add_argument('--limit', type=int, choices=range(1, 101), default=1)
    live.add_argument('--repeats', type=int, choices=range(1, 4), default=1)
    live.add_argument('--seed', type=int, default=0)
    live.add_argument('--scenario', action='append', help='Select a scenario ID; repeat for several IDs')
    worker = sub.add_parser('_step', help=argparse.SUPPRESS)
    worker.add_argument('directory', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'validate':
            dataset = Dataset.model_validate_json(args.dataset.read_bytes())
            print(json.dumps({'status': 'valid', 'scenarios': len(dataset.scenarios), 'split': dataset.split}))
            return 0
        if args.command == '_step':
            step_trial(args.directory)
            return 0
        return run(args)
    except ExtractionError as error:
        print(json.dumps({'error': error.code}), file=sys.stderr)
        return 1
    except ValidationError:
        print(json.dumps({'error': 'invalid_conversation_dataset'}), file=sys.stderr)
        return 1
    except (ValueError, OSError):
        print(json.dumps({'error': 'conversation_configuration_or_storage_error'}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
