"""Persistent simulated payments for conversation trials; no Stripe client."""

import hashlib
import json

from .recovery_provider import RecoveryProvider
from .stripe_gateway import SandboxError


class ConversationProvider(RecoveryProvider):
    def create_payment(self, params, key):
        suffix = hashlib.sha256(key.encode()).hexdigest()[:20]
        paid = params.get('confirm', False)
        payment = dict(id='pi_sim' + suffix, amount=params['amount'], currency=params['currency'],
                       status='succeeded' if paid else 'requires_payment_method', livemode=False,
                       operation_key=params['metadata']['payresolve_operation'], charge_id='ch_sim' + suffix,
                       paid=paid, captured=paid, disputed=False,
                       amount_captured=params['amount'] if paid else 0)
        with self.connect() as c:
            existing = c.execute('SELECT data_json FROM payments WHERE id=?', (payment['id'],)).fetchone()
            if existing and json.loads(existing[0]) != payment:
                raise SandboxError('provider_payment_conflict', 'Simulation fixture differs.')
            c.execute('INSERT OR IGNORE INTO payments VALUES (?,?)', (payment['id'], json.dumps(payment)))
        return payment['id']
